var db = require('seraph')('http://localhost:7474')
var model = require('seraph-model');
