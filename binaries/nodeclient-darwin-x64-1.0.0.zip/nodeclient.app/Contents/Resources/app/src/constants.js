const mainWindow = {
  CLOSED: 'closed',
  WIDTH: 800,
  HEIGHT: 600,
};

const appEvents = {
  READY: 'ready',
  WINDOW_ALL_CLOSED: 'window-all-closed',
  ACTIVATE: 'activate',
};

const server = {
  //HOST: 'localhost',
  HOST: 'ruinsofmidgaard.com',
  PORT: 5151,
};

const wsEvents = {
  OPEN: 'open',
  MESSAGE: 'message'
};

exports.mainWindow = mainWindow;
exports.appEvents = appEvents;
exports.server = server;
exports.wsEvents = wsEvents;
