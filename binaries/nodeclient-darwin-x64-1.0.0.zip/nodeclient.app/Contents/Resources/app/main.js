const { app, BrowserWindow } = require('electron');
const path = require('path');
const url = require('url');
const { appEvents, mainWindow, server } = require('./src/constants');

let win;

const loadWindow = () => {
  win = new BrowserWindow({
    width: mainWindow.WIDTH,
    height: mainWindow.HEIGHT,
      webPreferences: {
          nodeIntegration: true
      }
  })

  win.loadURL(url.format({
    pathname: path.join(__dirname, 'index.html'),
    protocol: 'file:',
    slashes: true,
  }))
}

const quit = () => {
  app.quit()
}

app.on(appEvents.READY, loadWindow)
app.on(appEvents.WINDOW_ALL_CLOSED, quit)
